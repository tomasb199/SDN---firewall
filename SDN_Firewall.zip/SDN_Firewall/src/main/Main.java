package main;

import gui.GUI_main;

import java.util.ArrayList;

import javax.swing.SwingUtilities;

public class Main {
		
	private GetTopology getTopology = new GetTopology();
	private GUI_main guiMain;
	public ArrayList<Rule> ruleList = new ArrayList<Rule>();
	
	public static void main(String[] args) throws Exception {	
		
		SwingUtilities.invokeLater(() -> {
			try {
				new GUI_main().initialize();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}
	
	public void getRestAPI(GUI_main gui) throws Exception {
		guiMain = gui;
		getTopology.getRestAPI(gui);
	}
	
	public void getDataFromGUI() {
		String[] tmp = guiMain.choice.getSelectedItem().toString().split(" ");
		String[] tmp2 = guiMain.choice_1.getSelectedItem().toString().split(" ");
		
		String from_ip = tmp[2].replaceAll("\\[|\\]|\"", "");
		String to_ip = tmp2[2].replaceAll("\\[|\\]|\"", "");
		
		boolean direction = false;
		if (guiMain.rdbtnOneway.isSelected())
			direction = false;
		else if (guiMain.rdbtnBidirectional.isSelected())
			direction = true;
		
		String permision = null;
		if (guiMain.rdbtnDeny.isSelected())
			permision = "DENY";
		else if (guiMain.rdbtnAllow.isSelected())
			permision = "ALLOW";
		
		String l2 = guiMain.choice_3.getSelectedItem().toString();
		String l3 = guiMain.choice_4.getSelectedItem().toString();
		String l4 = guiMain.choice_5.getSelectedItem().toString();
		
		String src_port = guiMain.textArea.getText();
		String dest_port = guiMain.textArea_1.getText();
		
		Rule newEntry = new Rule(from_ip, to_ip, l2, l3, l4, direction, permision, src_port, dest_port);
		ruleList.add(newEntry);
		
	}

}
