package main;

public class Link {
	
	public String src;
	public String dst;
	
	public Link(String src_in, String dst_in) {
		this.src = src_in;
		this.dst = dst_in;
	}

}
