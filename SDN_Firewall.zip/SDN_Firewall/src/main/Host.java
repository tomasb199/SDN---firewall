package main;

public class Host {

	public String sw_dipd;
	public String ipv4;
	public String name;
	
	
	public Host(String dpid_in, String ipv4_in) {
		
		this.sw_dipd = dpid_in;
		this.ipv4 = ipv4_in;
	}
}
