package gui;

import java.awt.Label;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;

public class GUI_allRules {
	
	private JFrame frame;
	
	public GUI_allRules() {		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 929, 489);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(true);
		
		Label label = new Label("All Active Firewall Rules:");
		label.setBounds(10, 10, 157, 24);
		frame.getContentPane().add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 40, 887, 361);
		frame.getContentPane().add(scrollPane);
		
		JButton btnNewButton = new JButton("Delete Selected Rule");
		btnNewButton.setBounds(10, 404, 151, 25);
		frame.getContentPane().add(btnNewButton);
	}

}
