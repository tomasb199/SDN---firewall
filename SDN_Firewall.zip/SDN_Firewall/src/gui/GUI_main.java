package gui;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;

import main.Main;

public class GUI_main {
	
	public JFrame frame;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	public GUI_allRules gui_all; 
	public JPanel panel;
	private Main main =  new Main();;
	public Choice choice;
	public Choice choice_1;
	public Choice choice_3;
	public Choice choice_4;
	public Choice choice_5;
	public JRadioButton rdbtnOneway, rdbtnBidirectional;
	public JRadioButton rdbtnAllow, rdbtnDeny;
	public JTextArea textArea, textArea_1;
	

	/**
	 * Initialize the contents of the frame.
	 * @param runnable 
	 * @throws Exception 
	 */
	@SuppressWarnings("serial")
	public void initialize() throws Exception{
		frame = new JFrame();
		frame.setVisible(true);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		//frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		choice = new Choice();
		choice.setBounds(152, 47, 215, 32);
		frame.getContentPane().add(choice);
		
		choice_1 = new Choice();
		choice_1.setBounds(152, 75, 215, 22);
		frame.getContentPane().add(choice_1);
		
		rdbtnOneway = new JRadioButton("one-way");
		rdbtnOneway.setSelected(true);
		buttonGroup.add(rdbtnOneway);
		rdbtnOneway.setBounds(152, 104, 84, 25);
		frame.getContentPane().add(rdbtnOneway);
		
		rdbtnBidirectional = new JRadioButton("bi-directional");
		buttonGroup.add(rdbtnBidirectional);
		rdbtnBidirectional.setBounds(258, 104, 109, 25);
		frame.getContentPane().add(rdbtnBidirectional);
		
		JLabel lblCurrentTopology = new JLabel("Current Topology:");
		lblCurrentTopology.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblCurrentTopology.setBounds(452, 9, 148, 31);
		frame.getContentPane().add(lblCurrentTopology);
		
		panel = new JPanel();
		panel = new JPanel(new GridLayout()){
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(578, 349);
            }
        };
		panel.setBorder(BorderFactory.createLineBorder(Color.black, 3));;
		panel.setBounds(452, 46, 1450, 944);
		frame.getContentPane().add(panel);
		
		JLabel lblToSetNew = new JLabel("To set new rule fill in the form:");
		lblToSetNew.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblToSetNew.setBounds(12, 9, 355, 31);
		frame.getContentPane().add(lblToSetNew);
		
		JLabel lblFrom = new JLabel("From:");
		lblFrom.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblFrom.setBounds(12, 47, 109, 22);
		frame.getContentPane().add(lblFrom);
		
		JLabel lblTo = new JLabel("To:");
		lblTo.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTo.setBounds(12, 75, 109, 22);
		frame.getContentPane().add(lblTo);
		
		JLabel lblDirection = new JLabel("Direction:");
		lblDirection.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDirection.setBounds(12, 104, 109, 22);
		frame.getContentPane().add(lblDirection);
		
		JLabel lblLLayer_1 = new JLabel("L2 layer:");
		lblLLayer_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblLLayer_1.setBounds(12, 163, 109, 22);
		frame.getContentPane().add(lblLLayer_1);
		
		choice_3 = new Choice();
		choice_3.setBounds(152, 163, 215, 22);
		frame.getContentPane().add(choice_3);
		
		JLabel lblLLayer_2 = new JLabel("L3 layer:");
		lblLLayer_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblLLayer_2.setBounds(12, 191, 109, 22);
		frame.getContentPane().add(lblLLayer_2);
		
		choice_4 = new Choice();
		choice_4.setBounds(152, 191, 215, 22);
		frame.getContentPane().add(choice_4);
		
		JLabel lblLLayer_3 = new JLabel("L4 layer:");
		lblLLayer_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblLLayer_3.setBounds(12, 219, 109, 22);
		frame.getContentPane().add(lblLLayer_3);
		
		choice_5 = new Choice();
		choice_5.setBounds(152, 219, 215, 22);
		frame.getContentPane().add(choice_5);
		
		String[] l4 = {"-", "TCP", "UDP", "ICMP" , "ICMPv6"};
		for (String s : l4) {
			choice_5.add(s);
		}
		
		String[] l2 = {"-", "ARP"};
		for (String s : l2) {
			choice_3.add(s);
		}
				
		String[] l3 = {"-", "IPv4", "IPv6"};
		for (String s : l3) {
			choice_4.add(s);
		}
		
		
		JLabel lblAction = new JLabel("Action:");
		lblAction.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAction.setBounds(12, 324, 56, 16);
		frame.getContentPane().add(lblAction);
		
		rdbtnAllow = new JRadioButton("ALLOW");
		buttonGroup_1.add(rdbtnAllow);
		rdbtnAllow.setSelected(true);
		rdbtnAllow.setBounds(152, 321, 84, 25);
		frame.getContentPane().add(rdbtnAllow);
		
		rdbtnDeny = new JRadioButton("DENY");
		buttonGroup_1.add(rdbtnDeny);
		rdbtnDeny.setBounds(240, 321, 84, 25);
		frame.getContentPane().add(rdbtnDeny);
		
		JButton btnCreateNewRule = new JButton("CREATE NEW RULE");
		btnCreateNewRule.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnCreateNewRule.setBounds(12, 353, 283, 27);
		frame.getContentPane().add(btnCreateNewRule);
		
		btnCreateNewRule.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				main.getDataFromGUI();
			}
		});
		
		JLabel lblOtherActions = new JLabel("Other Actions:\r\n");
		lblOtherActions.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblOtherActions.setBounds(12, 392, 355, 31);
		frame.getContentPane().add(lblOtherActions);
		
		JButton btnViewAndEdit = new JButton("View and Delete Rules");
		btnViewAndEdit.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnViewAndEdit.setBounds(12, 427, 283, 27);
		frame.getContentPane().add(btnViewAndEdit);
		
		JLabel lblSourcePort = new JLabel("Source port:\r\n");
		lblSourcePort.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblSourcePort.setBounds(12, 254, 109, 22);
		frame.getContentPane().add(lblSourcePort);
		
		JLabel lblDestinationPort = new JLabel("Destination port:");
		lblDestinationPort.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDestinationPort.setBounds(12, 289, 136, 22);
		frame.getContentPane().add(lblDestinationPort);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
		textArea.setBounds(152, 254, 215, 22);
		frame.getContentPane().add(textArea);
		
		textArea_1 = new JTextArea();
		textArea_1.setFont(new Font("Monospaced", Font.PLAIN, 14));
		textArea_1.setBounds(152, 289, 215, 22);
		frame.getContentPane().add(textArea_1);
		
		btnViewAndEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//gui_all = new GUI_allRules();
			}
		});
		
		
		main.getRestAPI(this);
	}
	

}
