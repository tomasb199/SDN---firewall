package main;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

import org.graphstream.graph.EdgeRejectedException;
import org.graphstream.graph.Graph;
import org.graphstream.graph.Node;
import org.graphstream.graph.implementations.SingleGraph;
import org.graphstream.ui.swingViewer.ViewPanel;
import org.graphstream.ui.view.Viewer;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import gui.GUI_main;

public class GetTopology {
	
	private final String USER_AGENT = "Mozilla/5.0";

	public ArrayList<Host> list_host = new ArrayList<Host>();
	public ArrayList<Switch> list_switch = new ArrayList<Switch>();
	public ArrayList<Link> list_link = new ArrayList<Link>();
	
	public void getRestAPI(GUI_main gui) throws Exception {

		String host_url = "http://192.168.56.101:8080/v1.0/topology/hosts";
		String link_url = "http://192.168.56.101:8080/v1.0/topology/links";
		String switch_url = "http://192.168.56.101:8080/v1.0/topology/switches";

		String host_json = readFile("hosts.json"); //sendGet(host_url);
		String links_json = readFile("links.json");//sendGet(link_url);
		String switch_json = readFile("switches.json");//sendGet(switch_url);

		ParseJSON(host_json, 1);
		ParseJSON(switch_json, 2);
		ParseJSON(links_json, 3);

		displayGraph(gui);
	}

	private void ParseJSON(String in, int type) throws ParseException {

		switch (type) {
		case 1: {
			JSONParser parser = new JSONParser();
			JSONArray array = (JSONArray) parser.parse(in);
			int host_num = 1;

			for (Object o : array) {
				JSONObject host = (JSONObject) o;
				String key = (host.get("ipv4")).toString();

				JSONObject port = (JSONObject) host.get("port");
				String dpid = (port.get("dpid")).toString();

				boolean in_l = false;

				/*
				for (Host h : list_host) {
					if (h.sw_dipd.equals(dpid)) {
						in_l = true;
					}
				}*/

				if (in_l == false) {
					Host NewHost = new Host(dpid, key);
					NewHost.name = "HOST " + host_num;
					list_host.add(NewHost);
					host_num++;
				}

			}
			break;
		}

		case 2: {
			JSONParser parser = new JSONParser();
			JSONArray array = (JSONArray) parser.parse(in);

			int sw_num = 1;

			for (Object o : array) {
				JSONObject switch_ = (JSONObject) o;
				String dpid = (switch_.get("dpid")).toString();

				boolean in_l = false;

				for (Switch s : list_switch) {
					if (s.dpid.equals(dpid)) {
						in_l = true;
					}
				}

				if (in_l == false) {
					Switch NewSwitch = new Switch(dpid, ("S " + sw_num));
					list_switch.add(NewSwitch);
					sw_num++;
				}
			}
			break;
		}
		case 3: {
			JSONParser parser = new JSONParser();
			JSONArray array = (JSONArray) parser.parse(in);

			for (Object o : array) {
				JSONObject link = (JSONObject) o;

				JSONObject src = (JSONObject) link.get("src");
				String src_add = (src.get("dpid")).toString();

				JSONObject dest = (JSONObject) link.get("dst");
				String dest_add = (dest.get("dpid")).toString();

				Link NewLink = new Link(src_add, dest_add);
				list_link.add(NewLink);
			}
			break;
		}
		}
	}

	private String sendGet(String in_url) throws Exception {

		URL obj = new URL(in_url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		// add request header
		con.setRequestProperty("User-Agent", USER_AGENT);

		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
		
		return response.toString();
	}

	public void displayGraph(GUI_main gui) {
		Graph graph = new SingleGraph("SDN");

		 graph.setStrict(false);

		for (Host h : list_host) {
			graph.addNode(h.ipv4);
			Node A = graph.getNode(h.ipv4);
			A.addAttribute("dipd", 1);
			A.addAttribute("ui.label", h.name + " " +A.getId());
			A.addAttribute("ui.style", "shape:circle;fill-color: yellow;size: 60px;");

		}
		for (Switch s : list_switch) {
			graph.addNode(s.name);
			Node A = graph.getNode(s.name);
			A.addAttribute("dipd", s.dpid);
			A.addAttribute("ui.style", "shape:circle; fill-color: black; size: 40px;");
			A.addAttribute("ui.label", A.getId());
		}

		int engde_count = 0;

		for (Link l : list_link) {
			Node A = null;
			Node B = null;

			for (Switch s : list_switch) {
				if (s.dpid.equals(l.dst) || s.dpid.equals(l.src)) {
					if (A == null) {
						A = graph.getNode(s.name);
						continue;
					}
					if (B == null) {
						B = graph.getNode(s.name);
						continue;
					}
				}
			}

			if (A != null && B != null) {
				try {
					graph.addEdge(Integer.toString(engde_count++), A, B);

				} catch (EdgeRejectedException e) {

				}
			}

		}

		for (Host h : list_host) {
			Node C = graph.getNode(h.ipv4);
			Node D = null;
			for (Node node : graph) {
				if ((node.getAttribute("dipd")).toString().equals(h.sw_dipd))
					D = graph.getNode(node.getId());
			}
			if (C != null && D != null) {
				graph.addEdge(Integer.toString(engde_count++), C, D);
			}

		}
		
		//graph.display();

		Viewer viewer = new Viewer(graph, Viewer.ThreadingModel.GRAPH_IN_ANOTHER_THREAD);
		viewer.enableAutoLayout();
        ViewPanel viewPanel = viewer.addDefaultView(false);        
        gui.panel.add(viewPanel);
        
        this.fillData(gui);
        
		
	}

	private void fillData(GUI_main gui) {
		
		for (Host h : list_host) {
			gui.choice.add(h.name + " " + h.ipv4);
			gui.choice_1.add(h.name+ " " + h.ipv4);
		}
		
		/*
		for (Switch s : list_switch) {
			gui.choice.add(s.name);
			gui.choice_1.add(s.name);
		}		*/
	}
	
	static String readFile(String path) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(path));

			String sCurrentLine, res = "";

			while ((sCurrentLine = br.readLine()) != null) {
				res += sCurrentLine;
			}
			return res;
	}

}
