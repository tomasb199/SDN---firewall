package main;

public class Switch {
	
	public String dpid;
	public String name;
	
	public Switch(String dpid_in, String name_in) {
		this.dpid = dpid_in;
		this.name = name_in;
	}

}
