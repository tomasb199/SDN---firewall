package main;

import org.json.JSONException;
import org.json.JSONObject;

public class Rule {
	
	private String ruleID;
	private String from;
	private String to;
	private String l2;
	private String l3;
	private String l4;
	private boolean direction; // 1 = bidirection; 0 = one-direction
	private String permision; // 1 = allow; 0 = deny
	private String src_port;
	private String dest_port;
	
	
	public String getFrom() {
		return from;
	}


	public String getTo() {
		return to;
	}


	public String getL2() {
		return l2;
	}


	public String getL3() {
		return l3;
	}


	public String getL4() {
		return l4;
	}


	public boolean isDirection() {
		return direction;
	}


	public String getPermision() {
		return permision;
	}


	public String getSrc_port() {
		return src_port;
	}


	public String getDest_port() {
		return dest_port;
	}
	
	public String getRuleID() {
		return ruleID;
	}


	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}
	public String getAllJSON() throws JSONException {
		
		JSONObject obj = new JSONObject();
        obj.put("nw_src", from);
        obj.put("nw_dst", to);
        if(!l2.equals("-"))
        	obj.put("dl_type", l2);
        if(!permision.equals("-"))
        	obj.put("actions", permision);
        if(!l4.equals("-"))
        	obj.put("nw_proto", l4);
        

	return obj.toString();
	}

	public Rule(String from, String to, String l2, String l3, String l4, boolean direcion, String permision, String src_port, String dest_port) {
		
		this.from = from;
		this.to = to;
		this.l2 = l2;
		this.l3 = l3;
		this.l4 = l4;
		this.direction = direcion;
		this.permision = permision;
		this.src_port = src_port;
		this.dest_port = dest_port;		
	
	}


	

}
